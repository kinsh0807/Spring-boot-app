package com.masai.app.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
