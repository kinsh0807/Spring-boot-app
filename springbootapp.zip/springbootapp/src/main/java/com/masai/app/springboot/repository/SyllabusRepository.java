package com.masai.app.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.app.springboot.entity.Syllabus;

public interface SyllabusRepository extends JpaRepository<Syllabus, Integer>{

}
